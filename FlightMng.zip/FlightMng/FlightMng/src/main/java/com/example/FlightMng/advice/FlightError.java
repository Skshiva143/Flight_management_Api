//package com.example.FlightMng.advice;
//
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.ExceptionHandler;
//import org.springframework.web.bind.annotation.RestControllerAdvice;
//
//import java.time.LocalDateTime;
//
//@RestControllerAdvice
//public class FlightError
//{
////    @ExceptionHandler(TouristNotFoundException.class)
////    public ResponseEntity<ErrorDetails> handleExceptionForTourist(TouristNotFoundException tn)
////    {
////        ErrorDetails er=new ErrorDetails("404 Not Found", tn.getMessage(), LocalDateTime.now());
////        return new ResponseEntity<ErrorDetails>(er, HttpStatus.BAD_REQUEST);
////    }
//
//    @ExceptionHandler(Exception.class)
//    public ResponseEntity<ErrorDetails> handleExceptionGlobally(Exception e)
//    {
//        ErrorDetails er=new ErrorDetails("500 server", e.getMessage(), LocalDateTime.now());
//        return new ResponseEntity<ErrorDetails>(er, HttpStatus.INTERNAL_SERVER_ERROR);
//    }
//}
