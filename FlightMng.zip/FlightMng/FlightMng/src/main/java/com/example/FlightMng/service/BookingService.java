package com.example.FlightMng.service;

import com.example.FlightMng.dto.BookingDto;
import com.example.FlightMng.entity.Booking;
import com.example.FlightMng.mapper.BookingMapper;
import com.example.FlightMng.repository.BookingRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookingService {

    @Autowired
    private BookingRepo bookingrepo;
    @Autowired
    private BookingMapper bookingMapper;

    public void createBooking(Booking booking){
        bookingrepo.save(booking);
    }
    public List<Booking>getBooking(){
        return bookingrepo.findAll();
    }
    public BookingDto getBookingById(Long id){
        return bookingMapper.entityToDtoMapper(bookingrepo.findById(id).orElseThrow(()->new RuntimeException("id"+id+" not found"))) ;
    }
    public void deleteBooking(Long id){
        bookingrepo.deleteById(id);
    }
    public void updateBooking(Long id, Booking booking){
        Booking booking1=bookingrepo.findById(id).orElseThrow(null);
        booking1.setBookingDate(booking.getBookingDate());
        booking1.setPassenger(booking.getPassenger());
        booking1.setScheduled_flight(booking.getScheduled_flight());
        booking1.setStatus(booking.getStatus());
        bookingrepo.save(booking1);
    }
}
