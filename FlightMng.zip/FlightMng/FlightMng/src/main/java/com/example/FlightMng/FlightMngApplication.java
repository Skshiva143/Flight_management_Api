package com.example.FlightMng;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication(scanBasePackages = "com.example.FlightMng")
public class FlightMngApplication {


	public static void main(String[] args) {
		SpringApplication.run(FlightMngApplication.class, args);
	}

}
