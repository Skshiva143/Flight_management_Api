package com.example.FlightMng.controller;

import com.example.FlightMng.dto.Scheduled_FlightDto;
import com.example.FlightMng.entity.Scheduled_Flight;
import com.example.FlightMng.service.Scheduled_Flight_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/scheduled_flights")
public class Scheduled_Flight_Controller {
    @Autowired
    private Scheduled_Flight_Service scheduledFlightService;

    @PostMapping
    public ResponseEntity<String> createScheduledFlight(@RequestBody Scheduled_Flight scheduled_flight) {
        scheduledFlightService.createScheduledFlight(scheduled_flight);
        return ResponseEntity.ok("posted Successfully");
    }

    @GetMapping
    public ResponseEntity<List<Scheduled_Flight>> getScheduledFlight() {
        return ResponseEntity.ok( scheduledFlightService.getScheduledFlight());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Scheduled_FlightDto> getScheduledFlightById(@PathVariable Long id) {
        return ResponseEntity.ok(scheduledFlightService.getScheduledFlightById(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteScheduledFlightById(@PathVariable Long id) {
        scheduledFlightService.deleteScheduleFlightById(id);
        return ResponseEntity.ok("deleted Successfully");
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateScheduleFlightById(@PathVariable Long id, @RequestBody Scheduled_Flight scheduled_flight) {
        scheduledFlightService.updateScheduledFlight(id, scheduled_flight);
        return ResponseEntity.ok("updated Successfully");
    }
}


