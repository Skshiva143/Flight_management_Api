//package com.example.FlightMng.config;
//
//import com.example.FlightMng.mapper.AirportMapper;
//import com.example.FlightMng.mapper.ScheduleMapper;
//import org.mapstruct.factory.Mappers;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//public class ScheduleConfig {
//    @Bean
//    public ScheduleMapper scheduleMapper() {
//        return Mappers.getMapper(ScheduleMapper.class);
//    }
////}
