package com.example.FlightMng.repository;

import com.example.FlightMng.entity.Airport;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AirportRepo extends JpaRepository<Airport,Long> {
}
