//package com.example.FlightMng.config;
//
//import com.example.FlightMng.mapper.AirportMapper;
//import com.example.FlightMng.mapper.FlightMapper;
//import org.mapstruct.factory.Mappers;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//public class FlightConfig {
//    @Bean
//    public FlightMapper flightMapper() {
//        return Mappers.getMapper(FlightMapper.class);
//    }
//}
