package com.example.FlightMng.controller;

import com.example.FlightMng.dto.BookingDto;
import com.example.FlightMng.entity.Booking;
import com.example.FlightMng.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/booking")
public class BookingController {
    @Autowired
    private BookingService bookingService;

    @PostMapping
    public ResponseEntity<String> createBooking(@RequestBody Booking booking){
        bookingService.createBooking(booking);
        return ResponseEntity.ok("Booking Added Successfully");
    }
    @GetMapping
    public ResponseEntity<List<Booking>>getBooking(){
        return ResponseEntity.ok(bookingService.getBooking());
    }
    @GetMapping("/{id}")
    public ResponseEntity<BookingDto> getBookingById(@PathVariable Long id){
        return ResponseEntity.ok(bookingService.getBookingById(id));
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteBookingById(@PathVariable Long id){
        bookingService.deleteBooking(id);
        return ResponseEntity.ok("Booking Deleted Successfully");
    }
    @PutMapping("/{id}")
    public ResponseEntity<String>updateBookingById(@PathVariable Long id, @RequestBody Booking booking) {
        bookingService.updateBooking(id, booking);
        return ResponseEntity.ok("Booking updated Successfully");
    }
}
