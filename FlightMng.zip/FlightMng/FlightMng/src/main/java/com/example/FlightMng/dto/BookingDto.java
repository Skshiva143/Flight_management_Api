package com.example.FlightMng.dto;

import com.example.FlightMng.entity.Passenger;
import com.example.FlightMng.entity.Scheduled_Flight;

import java.time.LocalDate;

public class BookingDto {
    private Long id;
    private Passenger passenger;
    private LocalDate bookingDate;
    private String status;
    private Scheduled_Flight scheduled_flight;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Passenger getPassenger() {
        return passenger;
    }

    public void setPassenger(Passenger passenger) {
        this.passenger = passenger;
    }

    public LocalDate getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(LocalDate bookingDate) {
        this.bookingDate = bookingDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Scheduled_Flight getScheduled_flight() {
        return scheduled_flight;
    }

    public void setScheduled_flight(Scheduled_Flight scheduled_flight) {
        this.scheduled_flight = scheduled_flight;
    }
}
