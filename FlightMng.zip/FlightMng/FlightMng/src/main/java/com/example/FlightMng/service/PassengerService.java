package com.example.FlightMng.service;

import com.example.FlightMng.dto.PassengerDto;
import com.example.FlightMng.entity.Passenger;
import com.example.FlightMng.mapper.PassengerMapper;
import com.example.FlightMng.repository.PassengerRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;
import java.util.Optional;

@Service
public class PassengerService {

    @Autowired
    private PassengerRepo passengerrepo;
    @Autowired
    private PassengerMapper passengerMapper;

    public List<Passenger> getAllPassenger(){
        return passengerrepo.findAll();
    }
    public PassengerDto getPassengerById(Long id){
        return passengerMapper.entityToDtoMapper(passengerrepo.findById(id).orElseThrow(()->new RuntimeException("id %id not found")));
    }
    public void  createPassenger(Passenger passenger){
        passengerrepo.save(passenger);
    }
    public void deletePassengerById(Long id){
        passengerrepo.deleteById(id);
    }
    public void updatePassengerById(Long id,Passenger passenger) {
        Passenger passenger1 =passengerrepo.findById(id).orElseThrow(null);
        passenger1.setDob(passenger.getDob());
        passenger1.setFname(passenger.getFname());
        passenger1.setLname(passenger.getLname());
        passenger1.setPhone_no(passenger.getPhone_no());
            passengerrepo.save(passenger);
    }

}
