package com.example.FlightMng.dto;

public class FlightDto {
    private Long id;
    private Integer flight_id;
    private String carrier_name;
    private String flight_model;
    private Integer seat_capacity;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getFlight_id() {
        return flight_id;
    }

    public void setFlight_id(Integer flight_id) {
        this.flight_id = flight_id;
    }

    public String getCarrier_name() {
        return carrier_name;
    }

    public void setCarrier_name(String carrier_name) {
        this.carrier_name = carrier_name;
    }

    public String getFlight_model() {
        return flight_model;
    }

    public void setFlight_model(String flight_model) {
        this.flight_model = flight_model;
    }

    public Integer getSeat_capacity() {
        return seat_capacity;
    }

    public void setSeat_capacity(Integer seat_capacity) {
        this.seat_capacity = seat_capacity;
    }
}
