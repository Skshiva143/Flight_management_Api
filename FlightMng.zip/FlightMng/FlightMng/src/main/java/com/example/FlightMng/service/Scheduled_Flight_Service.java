package com.example.FlightMng.service;

import com.example.FlightMng.dto.Scheduled_FlightDto;
import com.example.FlightMng.entity.Scheduled_Flight;
import com.example.FlightMng.mapper.Scheduled_FlightMapper;
import com.example.FlightMng.repository.Scheduled_Flight_Repo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class Scheduled_Flight_Service {

    @Autowired
    private Scheduled_Flight_Repo scheduled_flight_repo;
    @Autowired
    private Scheduled_FlightMapper scheduled_flightMapper;

    public List<Scheduled_Flight>getScheduledFlight(){
        return scheduled_flight_repo.findAll();
    }
    public Scheduled_FlightDto getScheduledFlightById( Long id){
        return scheduled_flightMapper.entityToDtoMapper(scheduled_flight_repo.findById(id).orElseThrow(()->new RuntimeException("Schedule_flight id %id not found")));
    }
    public void deleteScheduleFlightById(Long id){
        scheduled_flight_repo.deleteById(id);
    }
    public void  createScheduledFlight(Scheduled_Flight scheduled_flight ){
         scheduled_flight_repo.save(scheduled_flight);
    }
    public void updateScheduledFlight(Long id,Scheduled_Flight scheduled_flight){
        Scheduled_Flight scheduled_flight1=scheduled_flight_repo.findById(id).orElseThrow(null);
        scheduled_flight1.setSchedule(scheduled_flight.getSchedule());
        scheduled_flight1.setFlight(scheduled_flight.getFlight());
        scheduled_flight1.setSeats(scheduled_flight.getSeats());
             scheduled_flight_repo.save(scheduled_flight);
    }
}
