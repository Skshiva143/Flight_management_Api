package com.example.FlightMng.mapper;

import com.example.FlightMng.dto.AirportDto;
import com.example.FlightMng.dto.ScheduleDto;
import com.example.FlightMng.entity.Airport;
import com.example.FlightMng.entity.Schedule;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface ScheduleMapper {
    //AirportDto entityToDtoMapper(Airport entity);
    ScheduleDto entityToDtoMapper(Schedule entity);
}
