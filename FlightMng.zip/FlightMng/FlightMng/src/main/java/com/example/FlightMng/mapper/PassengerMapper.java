package com.example.FlightMng.mapper;

import com.example.FlightMng.dto.AirportDto;
import com.example.FlightMng.dto.PassengerDto;
import com.example.FlightMng.entity.Airport;
import com.example.FlightMng.entity.Passenger;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface PassengerMapper {
    //AirportDto entityToDtoMapper(Airport entity);
    PassengerDto entityToDtoMapper(Passenger entity);
}
