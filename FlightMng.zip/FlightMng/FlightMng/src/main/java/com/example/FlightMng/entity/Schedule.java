package com.example.FlightMng.entity;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name="schedule_data")
public class Schedule {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private LocalDateTime departure_time;
    private LocalDateTime arrival_time;
    @ManyToOne
    @JoinColumn(name = "departure_airport_id")
    private Airport departure_airport;
    @ManyToOne
    @JoinColumn(name = "arrival_airport_id")
    private Airport arrival_airport;

    public Schedule() {
    }

    public Schedule(Long id, LocalDateTime departure_time, LocalDateTime arrival_time, Airport departure_airport, Airport arrival_airport) {
        this.id = id;
        this.departure_time = departure_time;
        this.arrival_time = arrival_time;
        this.departure_airport = departure_airport;
        this.arrival_airport = arrival_airport;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDateTime getDeparture_time() {
        return departure_time;
    }

    public void setDeparture_time(LocalDateTime departure_time) {
        this.departure_time = departure_time;
    }

    public LocalDateTime getArrival_time() {
        return arrival_time;
    }

    public void setArrival_time(LocalDateTime arrival_time) {
        this.arrival_time = arrival_time;
    }

    public Airport getDeparture_airport() {
        return departure_airport;
    }

    public void setDeparture_airport(Airport departure_airport) {
        this.departure_airport = departure_airport;
    }

    public Airport getArrival_airport() {
        return arrival_airport;
    }

    public void setArrival_airport(Airport arrival_airport) {
        this.arrival_airport = arrival_airport;
    }
}
