package com.example.FlightMng.service;

import com.example.FlightMng.dto.FlightDto;
import com.example.FlightMng.entity.Flight;
import com.example.FlightMng.mapper.FlightMapper;
import com.example.FlightMng.repository.FlightRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;
import java.util.Optional;

@Service
public class FlightService {

    @Autowired
    private FlightRepo flightrepo;
    @Autowired
    private FlightMapper flightMapper;

    public List<Flight>getAllFlight(){
        return flightrepo.findAll();
    }
    public FlightDto getFlightById(Long id){
        return flightMapper.entityToDtoMapper(flightrepo.findById(id).orElseThrow(()->new RuntimeException("id %id not found")));
    }
    public void createFlight(Flight flight){
         flightrepo.save(flight);
    }
    public void deleteFlightById(Long id){
        flightrepo.deleteById(id);
    }
    public void  updateFlightById(Long id,Flight flight) {
        Flight flight1= flightrepo.findById(id).orElseThrow(null);
        flight1.setFlight_model(flight.getFlight_model());
        flight1.setCarrier_name(flight.getCarrier_name());
        flight1.setFlight_id(flight.getFlight_id());
        flight1.setSeat_capacity(flight.getSeat_capacity());
            flightrepo.save(flight1);
    }
}
