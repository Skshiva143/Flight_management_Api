package com.example.FlightMng.mapper;

import com.example.FlightMng.dto.AirportDto;
import com.example.FlightMng.dto.BookingDto;
import com.example.FlightMng.entity.Airport;
import com.example.FlightMng.entity.Booking;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface BookingMapper {
    BookingDto entityToDtoMapper(Booking entity);
}
