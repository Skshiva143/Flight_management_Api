package com.example.FlightMng.mapper;

import com.example.FlightMng.dto.AirportDto;
import com.example.FlightMng.dto.FlightDto;
import com.example.FlightMng.entity.Airport;
import com.example.FlightMng.entity.Flight;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface FlightMapper {
    //
    FlightDto entityToDtoMapper(Flight entity);
}
