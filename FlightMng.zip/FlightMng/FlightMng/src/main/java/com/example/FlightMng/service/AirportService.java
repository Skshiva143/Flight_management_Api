package com.example.FlightMng.service;

import com.example.FlightMng.dto.AirportDto;
import com.example.FlightMng.entity.Airport;
import com.example.FlightMng.mapper.AirportMapper;
import com.example.FlightMng.repository.AirportRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AirportService {
    @Autowired
    private AirportRepo airportrepo;

    @Autowired
    private AirportMapper airportMapper;

    public List<Airport> getAllAirports(){
        return airportrepo.findAll();
    }

    public AirportDto getAirportById(Long id){
        return airportMapper.entityToDtoMapper(airportrepo.findById(id).orElseThrow(()->new RuntimeException("id "+id+" not found")));
    }

    public void createAirport(Airport airport){
        airportrepo.save(airport);
    }

    public void deleteAirportById(Long id){
        airportrepo.deleteById(id);
    }

    public void updateAirportById(Long id, Airport airport){
        Airport airport1=airportrepo.findById(id).orElseThrow(null);
        airport1.setAirport_code(airport.getAirport_code());
        airport1.setAirport_name(airport.getAirport_name());
        airport1.setCity(airport.getCity());
        airport1.setCountry(airport.getCountry());
        airport1.setLatitude(airport.getLatitude());
        airport1.setLongitude(airport.getLongitude());
        airportrepo.save(airport1);
    }
}

