package com.example.FlightMng.repository;

import com.example.FlightMng.entity.Schedule;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ScheduleRepo  extends JpaRepository<Schedule,Long> {

}
