package com.example.FlightMng.repository;

import com.example.FlightMng.entity.Scheduled_Flight;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Scheduled_Flight_Repo extends JpaRepository<Scheduled_Flight,Long> {
}
