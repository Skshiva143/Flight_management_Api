package com.example.FlightMng.repository;

import com.example.FlightMng.entity.Passenger;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PassengerRepo extends JpaRepository<Passenger,Long> {
}
