package com.example.FlightMng.controller;

import com.example.FlightMng.dto.ScheduleDto;
import com.example.FlightMng.entity.Schedule;
import com.example.FlightMng.service.ScheduleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/schedules")
public class ScheduleController {
    @Autowired
    private ScheduleService scheduleService;

    @PostMapping
    public ResponseEntity<String> createSchedule(@RequestBody Schedule schedule){
        scheduleService.createSchedule(schedule);
        return ResponseEntity.ok("posted Successfully");
    }
    @GetMapping
    public ResponseEntity<List<Schedule>>getAllSchedules(){
        return ResponseEntity.ok(scheduleService.getAllSchedule());
    }
    @GetMapping("/{id}")
    public ResponseEntity<ScheduleDto> getAllScheduleById(@PathVariable Long id){
        return ResponseEntity.ok(scheduleService.getAllScheduleById(id));
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<String>deleteScheduleById(@PathVariable Long id){
        scheduleService.deleteSchedule(id);
        return ResponseEntity.ok("Deleted Succesfully");
    }
    @PutMapping("/{id}")
    public ResponseEntity<String> updateScheduleById(@PathVariable Long id, @RequestBody Schedule schedule){
         scheduleService.updateSchedule(id, schedule);
         return ResponseEntity.ok("updated Successfully");
    }
}
