package com.example.FlightMng.controller;

import com.example.FlightMng.dto.AirportDto;
import com.example.FlightMng.entity.Airport;
import com.example.FlightMng.service.AirportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("api/airports")
public class AirportController {

    @Autowired
    private AirportService airportService;

    @PostMapping
    public ResponseEntity<String> createAirport(@RequestBody Airport airport) {
         airportService.createAirport(airport);
         return ResponseEntity.ok("Airport Added Successfully");
    }

    @GetMapping
    public ResponseEntity<List<Airport>> getAllAirport() {
        return  ResponseEntity.ok(airportService.getAllAirports());
    }

    @GetMapping("/{id}")
    public ResponseEntity<AirportDto> getAirportById(@PathVariable Long id) {
        return ResponseEntity.ok( airportService.getAirportById(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteAirportById(@PathVariable Long id) {
        airportService.deleteAirportById(id);
        return ResponseEntity.ok("Airport Deleted Successfully");
    }
    @PutMapping("/{id}")
    public ResponseEntity<String>updateAirportById(@PathVariable Long id,@RequestBody Airport airport){
        airportService.updateAirportById(id,airport);
        return ResponseEntity.ok("Airport Updated Successfully");
    }
}

