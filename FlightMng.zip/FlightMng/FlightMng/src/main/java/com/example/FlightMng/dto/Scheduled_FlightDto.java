package com.example.FlightMng.dto;

import com.example.FlightMng.entity.Flight;
import com.example.FlightMng.entity.Schedule;


public class Scheduled_FlightDto {
    private Long id;
    private Flight flight;
    private Schedule schedule;
    private Integer seats;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Flight getFlight() {
        return flight;
    }

    public void setFlight(Flight flight) {
        this.flight = flight;
    }

    public Schedule getSchedule() {
        return schedule;
    }

    public void setSchedule(Schedule schedule) {
        this.schedule = schedule;
    }

    public Integer getSeats() {
        return seats;
    }

    public void setSeats(Integer seats) {
        this.seats = seats;
    }
}
