package com.example.FlightMng.mapper;

import com.example.FlightMng.dto.AirportDto;
import com.example.FlightMng.entity.Airport;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface AirportMapper {
    AirportDto entityToDtoMapper(Airport entity);
}
