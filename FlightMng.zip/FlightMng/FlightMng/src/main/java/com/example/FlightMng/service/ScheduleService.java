package com.example.FlightMng.service;

import com.example.FlightMng.dto.ScheduleDto;
import com.example.FlightMng.entity.Schedule;
import com.example.FlightMng.mapper.ScheduleMapper;
import com.example.FlightMng.repository.ScheduleRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;
import java.util.Optional;

@Service
public class ScheduleService {
    @Autowired
    private ScheduleRepo schedulerepo;
    @Autowired
    private ScheduleMapper scheduleMapper;

    public List<Schedule>getAllSchedule(){
        return schedulerepo.findAll();
    }
    public ScheduleDto getAllScheduleById(Long id){
        return scheduleMapper.entityToDtoMapper(schedulerepo.findById(id).orElseThrow(()->new RuntimeException("Schedule id %id not found"))) ;
    }
    public Schedule createSchedule( Schedule schedule){
        return schedulerepo.save(schedule);
    }
    public void deleteSchedule( Long id){
        schedulerepo.deleteById(id);
    }
    public void  updateSchedule(Long id, Schedule schedule) {
        Schedule schedule1=schedulerepo.findById(id).orElseThrow(null);
        schedule1.setDeparture_time(schedule.getDeparture_time());
        schedule1.setDeparture_airport(schedule.getDeparture_airport());
        schedule1.setArrival_airport(schedule.getArrival_airport());
        schedule1.setArrival_time(schedule.getArrival_time());
             schedulerepo.save(schedule);
    }
}
