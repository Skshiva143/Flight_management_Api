package com.example.FlightMng.entity;

import jakarta.persistence.*;

@Entity
@Table(name="scheduled_flight_data")
public class Scheduled_Flight {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name="flight_id")
    private Flight flight;

    @ManyToOne
    @JoinColumn(name="schedule_id")
    private Schedule schedule;

    private Integer seats;

    public Scheduled_Flight() {
    }

    public Scheduled_Flight(Long id, Flight flight, Schedule schedule,Integer seats) {
        this.id = id;
        this.flight = flight;
        this.schedule = schedule;
        this.seats=seats;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Flight getFlight() {
        return flight;
    }

    public void setFlight(Flight flight) {
        this.flight = flight;
    }

    public Schedule getSchedule() {
        return schedule;
    }

    public void setSchedule(Schedule schedule) {
        this.schedule = schedule;
    }

    public Integer getSeats() {
        return seats;
    }

    public void setSeats(Integer seats) {
        this.seats = seats;
    }
}
