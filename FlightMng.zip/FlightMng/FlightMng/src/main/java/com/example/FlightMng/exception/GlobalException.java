//package com.example.FlightMng.exception;
//
//public class GlobalException {
//}
