package com.example.FlightMng.controller;

import com.example.FlightMng.dto.PassengerDto;
import com.example.FlightMng.entity.Passenger;
import com.example.FlightMng.service.PassengerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/passengers")
public class PassengerController {

    @Autowired
    public PassengerService passengerService;

    @PostMapping
    public ResponseEntity<String> createPassenger(@RequestBody Passenger passenger) {
         passengerService.createPassenger(passenger);
         return ResponseEntity.ok("Passenger Posted Successfully");
    }

    @GetMapping
    public ResponseEntity<List<Passenger>> getAllPassenger() {
       return  ResponseEntity.ok(passengerService.getAllPassenger());
    }

    @GetMapping("/{id}")
    public ResponseEntity<PassengerDto> getAllPassengerById(@PathVariable Long id) {
        return ResponseEntity.ok(passengerService.getPassengerById(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deletePassengerById(@PathVariable Long id) {
        passengerService.deletePassengerById(id);
        return ResponseEntity.ok("Passenger Deleted Successfully");
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updatePassengerById(@PathVariable Long id, @RequestBody Passenger passenger) {
         passengerService.updatePassengerById(id,passenger);
         return ResponseEntity.ok("Passenger Updated Successfully");
    }
}
