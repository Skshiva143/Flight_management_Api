package com.example.FlightMng.entity;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.util.List;
@Entity
@Table(name="booking_data")
public class Booking {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne
    @JoinColumn(name = "passenger_id")
    private Passenger passenger;
    private LocalDate bookingDate;
    private String status;
    @ManyToOne
    @JoinColumn(name="Scheduled_flight_id")
    private Scheduled_Flight scheduled_flight;

    public Booking(Long id, Passenger passenger, LocalDate bookingDate, String status) {
        this.id = id;
        this.passenger = passenger;
        this.bookingDate = bookingDate;
        this.status = status;
    }

    public Booking() {
    }

    public LocalDate getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(LocalDate bookingDate) {
        this.bookingDate = bookingDate;
    }

    public Passenger getPassenger() {
        return passenger;
    }

    public void setPassenger(Passenger passenger) {
        this.passenger = passenger;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Scheduled_Flight getScheduled_flight() {
        return scheduled_flight;
    }

    public void setScheduled_flight(Scheduled_Flight scheduled_flight) {
        this.scheduled_flight = scheduled_flight;
    }
}
