package com.example.FlightMng.controller;

import com.example.FlightMng.dto.FlightDto;
import com.example.FlightMng.entity.Flight;
import com.example.FlightMng.service.FlightService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/flights")
public class FlightController {

    @Autowired
    public FlightService flightService;

    @PostMapping
    public ResponseEntity<String> createFlight(@RequestBody Flight flight){
         flightService.createFlight(flight);
         return ResponseEntity.ok("Flight created successfully");
    }
    @GetMapping
    public ResponseEntity<List<Flight>>getAllFlights(){
        return ResponseEntity.ok(flightService.getAllFlight());
    }
    @GetMapping("/{id}")
    public ResponseEntity<FlightDto> getAllFlightsById(@PathVariable Long id){
        return ResponseEntity.ok(flightService.getFlightById(id));
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteFlightById(@PathVariable Long id){
        flightService.deleteFlightById(id);
        return ResponseEntity.ok("Flight Deleted Successfully");
    }
    @PutMapping("/{id}")
    public ResponseEntity<String> updateFlightById(@PathVariable Long id, @RequestBody Flight flight) {
        flightService.updateFlightById(id,flight);
        return ResponseEntity.ok("Flight updated Successfully ");

    }
}
